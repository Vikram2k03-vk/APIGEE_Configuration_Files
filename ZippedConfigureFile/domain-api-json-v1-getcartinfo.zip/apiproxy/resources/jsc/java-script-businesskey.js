var businessKey = "UNDEFINED";
context.setVariable("flow.custom.businessKey", businessKey);
